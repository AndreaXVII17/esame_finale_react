export default function CartItem({ item, onIncrease, onDecrease, onRemove }) {
  return (
    <div className="list-group-item d-flex flex-column gap-2">
      <div className="d-flex justify-content-between align-items-start gap-2">
        <div>
          <h4 className="h6 mb-1">{item.name}</h4>
          <p className="mb-0 text-muted small">€ {item.price.toFixed(2)}</p>
        </div>
        <strong>€ {(item.price * item.quantity).toFixed(2)}</strong>
      </div>
      <div className="d-flex flex-wrap align-items-center gap-2">
        <div className="btn-group" role="group" aria-label={`Quantità di ${item.name}`}>
          <button
            type="button"
            className="btn btn-outline-secondary btn-sm"
            onClick={() => onDecrease(item.id)}
          >
            -
          </button>
          <button type="button" className="btn btn-outline-secondary btn-sm" disabled>
            {item.quantity}
          </button>
          <button
            type="button"
            className="btn btn-outline-secondary btn-sm"
            onClick={() => onIncrease(item.id)}
          >
            +
          </button>
        </div>
        <button
          type="button"
          className="btn btn-sm btn-outline-danger ms-auto"
          onClick={() => onRemove(item.id)}
        >
          Rimuovi
        </button>
      </div>
    </div>
  )
}