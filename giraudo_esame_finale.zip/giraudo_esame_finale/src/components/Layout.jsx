import { Outlet } from 'react-router-dom'
import { useContext } from 'react'
import Header from './Header'
import CartSidebar from './CartSidebar'
import { CartContext } from '../store/cartContext'

export default function Layout() {
  const {
    cartItems,
    cartTotal,
    increaseQuantity,
    decreaseQuantity,
    removeFromCart,
    clearCart,
  } = useContext(CartContext)

  return (
    <div className="min-vh-100 bg-light d-flex flex-column">
      <Header />
      <main className="flex-grow-1 py-4">
        <div className="container-fluid px-4">
          <div className="row g-4 align-items-start">
            <div className="col-12 col-xl-9">
              <Outlet />
            </div>
            <div className="col-12 col-xl-3">
              <CartSidebar
                cartItems={cartItems}
                cartTotal={cartTotal}
                onIncrease={increaseQuantity}
                onDecrease={decreaseQuantity}
                onRemove={removeFromCart}
                onClear={clearCart}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}