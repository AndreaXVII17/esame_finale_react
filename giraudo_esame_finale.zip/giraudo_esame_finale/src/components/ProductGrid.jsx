import ProductCard from './ProductCard'

export default function ProductGrid({ products, onAddToCart }) {
  return (
    <div className="row g-4">
      {products.map((product) => (
        <div className="col-12 col-md-6 col-xl-4" key={product.id}>
          <ProductCard product={product} onAddToCart={onAddToCart} />
        </div>
      ))}
    </div>
  )
}