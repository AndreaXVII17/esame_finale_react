import { Link } from 'react-router-dom'

export default function ProductCard({ product, onAddToCart }) {
  return (
    <div className="card h-100 shadow-sm border-0">
      <Link to={`/products/${product.id}`} className="text-decoration-none text-dark">
        <img
          src={product.img}
          className="card-img-top"
          alt={product.name}
        />
      </Link>
      <div className="card-body d-flex flex-column">
        <span className="badge text-bg-secondary align-self-start mb-2">
          {product.category}
        </span>
        <h3 className="h5 card-title">
          <Link to={`/products/${product.id}`} className="text-decoration-none text-dark">
            {product.name}
          </Link>
        </h3>
        <p className="card-text text-muted mb-3">€ {product.price.toFixed(2)}</p>
        <div className="mt-auto d-flex gap-2">
          <Link className="btn btn-outline-dark flex-grow-1" to={`/products/${product.id}`}>
            Dettagli
          </Link>
          <button
            type="button"
            className="btn btn-primary flex-grow-1"
            onClick={() => onAddToCart(product)}
          >
            Aggiungi al carrello
          </button>
        </div>
      </div>
    </div>
  )
}