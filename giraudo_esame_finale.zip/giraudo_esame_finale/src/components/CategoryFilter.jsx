export default function CategoryFilter({ categories, value, onChange }) {
  return (
    <div className="mb-3">
      <label className="form-label fw-semibold" htmlFor="category-filter">
        Filtra per categoria
      </label>
      <select
        id="category-filter"
        className="form-select"
        value={value}
        onChange={onChange}
      >
        <option value="All">Tutte le categorie</option>
        {categories.map((category) => (
          <option key={category} value={category}>
            {category}
          </option>
        ))}
      </select>
    </div>
  )
}