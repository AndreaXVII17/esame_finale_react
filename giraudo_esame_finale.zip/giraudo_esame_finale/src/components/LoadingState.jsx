export default function LoadingState() {
  return (
    <div className="d-flex justify-content-center align-items-center py-5">
      <div className="text-center">
        <div className="spinner-border text-warning mb-3" role="status" aria-hidden="true" />
        <p className="mb-0 fw-semibold">Loading...</p>
      </div>
    </div>
  )
}