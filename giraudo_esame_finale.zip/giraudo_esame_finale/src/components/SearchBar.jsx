export default function SearchBar({ value, onChange }) {
  return (
    <div className="mb-3">
      <label className="form-label fw-semibold" htmlFor="product-search">
        Cerca un prodotto
      </label>
      <input
        id="product-search"
        type="text"
        className="form-control"
        placeholder="Inserisci il nome della bevanda"
        value={value}
        onChange={onChange}
      />
    </div>
  )
}