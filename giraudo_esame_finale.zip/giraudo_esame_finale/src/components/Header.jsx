import { NavLink } from 'react-router-dom'

export default function Header() {
  return (
    <header className="navbar navbar-expand-lg navbar-dark bg-dark border-bottom border-secondary sticky-top">
      <div className="container-fluid px-4">
        <NavLink className="navbar-brand fw-bold text-uppercase" to="/">
          Hookah & Beans
        </NavLink>
        <div className="navbar-nav ms-auto">
          <NavLink
            className={({ isActive }) =>
              `nav-link ${isActive ? 'active fw-semibold text-warning' : ''}`
            }
            to="/"
            end
          >
            Vetrina
          </NavLink>
        </div>
      </div>
    </header>
  )
}