import CartItem from './CartItem'

export default function CartSidebar({
  cartItems,
  cartTotal,
  onIncrease,
  onDecrease,
  onRemove,
  onClear,
}) {
  return (
    <aside className="card shadow-sm border-0 sticky-top cart-panel">
      <div className="card-header bg-dark text-white d-flex justify-content-between align-items-center">
        <span className="fw-semibold">Carrello</span>
        <span className="badge text-bg-light text-dark">{cartItems.length}</span>
      </div>
      <div className="card-body">
        {cartItems.length === 0 ? (
          <p className="mb-0 text-muted">Il carrello è vuoto.</p>
        ) : (
          <div className="list-group list-group-flush">
            {cartItems.map((item) => (
              <CartItem
                key={item.id}
                item={item}
                onIncrease={onIncrease}
                onDecrease={onDecrease}
                onRemove={onRemove}
              />
            ))}
          </div>
        )}
      </div>
      <div className="card-footer bg-white">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <span className="fw-semibold">Totale</span>
          <strong>€ {cartTotal.toFixed(2)}</strong>
        </div>
        <button
          type="button"
          className="btn btn-outline-secondary w-100"
          onClick={onClear}
          disabled={cartItems.length === 0}
        >
          Svuota carrello
        </button>
      </div>
    </aside>
  )
}