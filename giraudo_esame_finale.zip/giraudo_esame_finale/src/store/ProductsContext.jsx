import { useEffect, useState } from 'react'
import BEVANDE_MOCK from '../data/beverages'
import { ProductsContext } from './productsContext'

export default function ProductsProvider({ children }) {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      try {
        setProducts(BEVANDE_MOCK)
      } catch {
        setError('Impossibile caricare i prodotti.')
      } finally {
        setLoading(false)
      }
    }, 600)

    return () => window.clearTimeout(timeoutId)
  }, [])

  return (
    <ProductsContext.Provider value={{ products, loading, error }}>
      {children}
    </ProductsContext.Provider>
  )
}