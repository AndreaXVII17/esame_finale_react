const BEVANDE_MOCK = [
  {
    id: '1',
    name: 'Nitro Cold Brew',
    category: 'Caffè',
    price: 4.5,
    caffeine: 'Alta',
    ingredients: 'Caffè estratto a freddo, azoto',
    description:
      'Un cold brew cremoso e intenso, servito con una texture vellutata e un profilo aromatico pulito.',
    img: 'https://placehold.co/300x200?text=Nitro+Cold+Brew',
  },
  {
    id: '2',
    name: 'Matcha Latte Energetico',
    category: 'Tè',
    price: 5.0,
    caffeine: 'Media',
    ingredients: "Polvere di Matcha biologico, latte d'avena, ginseng",
    description:
      'Una bevanda equilibrata con note vegetali e una spinta energizzante delicata ma costante.',
    img: 'https://placehold.co/300x200?text=Matcha+Latte',
  },
  {
    id: '3',
    name: 'Monster Ginger Craft',
    category: 'Energy',
    price: 3.8,
    caffeine: 'Molto Alta',
    ingredients: 'Estratto di zenzero, taurina naturale, guaranà',
    description:
      'Energy drink artigianale dal gusto deciso, con una combinazione speziata e una carica immediata.',
    img: 'https://placehold.co/300x200?text=Monster+Ginger',
  },
  {
    id: '4',
    name: 'Espresso Tonico al Limone',
    category: 'Caffè',
    price: 4.0,
    caffeine: 'Alta',
    ingredients: 'Espresso double-shot, acqua tonica, scorza di limone',
    description:
      'Una combinazione fresca e brillante, pensata per chi vuole un espresso fuori dagli schemi.',
    img: 'https://placehold.co/300x200?text=Espresso+Tonic',
  },
  {
    id: '5',
    name: "Infuso d'Ibisco e Guaranà",
    category: 'Tè',
    price: 3.5,
    caffeine: 'Bassa',
    ingredients: 'Fiori di ibisco, estratto di guaranà, miele',
    description:
      'Un infuso fruttato e leggermente stimolante, perfetto per una pausa leggera ma aromatica.',
    img: 'https://placehold.co/300x200?text=Infuso+Ibisco',
  },
]

export default BEVANDE_MOCK