import { useContext } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { CartContext } from '../store/cartContext'
import { ProductsContext } from '../store/productsContext'
import LoadingState from '../components/LoadingState'

export default function ProductDetailPage() {
  const { productId } = useParams()
  const navigate = useNavigate()
  const { products, loading, error } = useContext(ProductsContext)
  const { addToCart } = useContext(CartContext)

  if (loading) {
    return <LoadingState />
  }

  if (error) {
    return <div className="alert alert-danger">{error}</div>
  }

  const product = products.find((item) => item.id === productId)

  if (!product) {
    return (
      <div className="alert alert-warning d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
        <span>Prodotto non trovato.</span>
        <Link className="btn btn-dark" to="/">
          Torna alla vetrina
        </Link>
      </div>
    )
  }

  return (
    <div className="card border-0 shadow-sm overflow-hidden">
      <div className="row g-0">
        <div className="col-12 col-lg-5">
          <img src={product.img} className="img-fluid h-100 object-fit-cover" alt={product.name} />
        </div>
        <div className="col-12 col-lg-7">
          <div className="card-body p-4 p-lg-5">
            <span className="badge text-bg-secondary mb-3">{product.category}</span>
            <h1 className="h2 fw-bold mb-3">{product.name}</h1>
            <p className="text-muted mb-4">{product.description}</p>

            <div className="row g-3 mb-4">
              <div className="col-12 col-md-4">
                <div className="border rounded-3 p-3 h-100 bg-light">
                  <p className="small text-uppercase text-muted mb-1">Prezzo</p>
                  <strong>€ {product.price.toFixed(2)}</strong>
                </div>
              </div>
              <div className="col-12 col-md-4">
                <div className="border rounded-3 p-3 h-100 bg-light">
                  <p className="small text-uppercase text-muted mb-1">Caffeina</p>
                  <strong>{product.caffeine}</strong>
                </div>
              </div>
              <div className="col-12 col-md-4">
                <div className="border rounded-3 p-3 h-100 bg-light">
                  <p className="small text-uppercase text-muted mb-1">Ingredienti</p>
                  <strong>{product.ingredients}</strong>
                </div>
              </div>
            </div>

            <div className="d-flex flex-wrap gap-2">
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => addToCart(product)}
              >
                Aggiungi al carrello
              </button>
              <button
                type="button"
                className="btn btn-outline-secondary"
                onClick={() => navigate('/')}
              >
                Torna indietro
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}