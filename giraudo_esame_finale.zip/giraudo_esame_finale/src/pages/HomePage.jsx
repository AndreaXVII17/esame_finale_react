import { useContext, useMemo, useState } from 'react'
import { CartContext } from '../store/cartContext'
import { ProductsContext } from '../store/productsContext'
import SearchBar from '../components/SearchBar'
import CategoryFilter from '../components/CategoryFilter'
import ProductGrid from '../components/ProductGrid'
import LoadingState from '../components/LoadingState'

export default function HomePage() {
  const { products, loading, error } = useContext(ProductsContext)
  const { addToCart } = useContext(CartContext)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')

  const categories = useMemo(
    () => [...new Set(products.map((product) => product.category))],
    [products],
  )

  const filteredProducts = useMemo(() => {
    const normalizedSearchTerm = searchTerm.trim().toLowerCase()

    return products.filter((product) => {
      const matchesSearch = product.name.toLowerCase().includes(normalizedSearchTerm)
      const matchesCategory =
        selectedCategory === 'All' || product.category === selectedCategory

      return matchesSearch && matchesCategory
    })
  }, [products, searchTerm, selectedCategory])

  if (loading) {
    return <LoadingState />
  }

  if (error) {
    return <div className="alert alert-danger">{error}</div>
  }

  return (
    <section>
      <div className="p-4 p-lg-5 mb-4 rounded-4 bg-white shadow-sm border">
        <p className="text-uppercase text-warning fw-semibold mb-2">
          Hookah & Beans
        </p>
        <h1 className="display-5 fw-bold mb-3">Bevande speciali per ogni pausa</h1>
        <p className="lead text-muted mb-0">
          Cerca, filtra e aggiungi al carrello caffè, tè ed energy drink artigianali.
        </p>
      </div>

      <div className="row g-3 mb-4">
        <div className="col-12 col-lg-7">
          <SearchBar
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
          />
        </div>
        <div className="col-12 col-lg-5">
          <CategoryFilter
            categories={categories}
            value={selectedCategory}
            onChange={(event) => setSelectedCategory(event.target.value)}
          />
        </div>
      </div>

      {filteredProducts.length === 0 ? (
        <div className="alert alert-info">Nessun prodotto corrisponde ai filtri scelti.</div>
      ) : (
        <ProductGrid products={filteredProducts} onAddToCart={addToCart} />
      )}
    </section>
  )
}