import { Link } from 'react-router-dom'

export default function NotFoundPage() {
  return (
    <div className="card border-0 shadow-sm p-5 text-center">
      <h1 className="display-6 fw-bold mb-3">Pagina non trovata</h1>
      <p className="text-muted mb-4">La route richiesta non esiste.</p>
      <div>
        <Link className="btn btn-dark" to="/">
          Torna alla vetrina
        </Link>
      </div>
    </div>
  )
}